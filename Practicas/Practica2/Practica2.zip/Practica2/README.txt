Este directorio contiene los ficheros correspondientes a la práctica 2 de la asignatura Desarrollo y Evaluación de Sistemas Software Interactivos del MII realizados por:
 
    Mario Ortega Aguayo  					              
    Manuel Jesús García Manday
    Pablo Martín-Moreno Ruíz	
    María Victoria Santiago Alcalá              		              
                                           

Contiene cuatro documentos pdf:
    
    - DocumentoVision.pdf : Documento de visión del producto a desarrollar y del alcance del proyecto.
    - PlantillaEscenarios.pdf : Conjunto de plantillas con la descripción de los escenarios seleccionados de uso del sistema.
    - PlantillaPersonajes.pdf : Conjunto de plantillas con la descripción de usuarios prioritarios del sistema.
    - storyboards.pdf : Imágenes con los storyboard creados para los escenario.



